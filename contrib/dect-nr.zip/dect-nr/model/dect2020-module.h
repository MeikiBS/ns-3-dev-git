/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#ifndef DECT2020_MODULE_H
#define DECT2020_MODULE_H

#include "dect2020-net-device.h"
#include "dect2020-mac.h"
#include "dect2020-phy.h"
#include "dect2020-channel.h"

// Fügen Sie hier weitere öffentliche Header-Dateien Ihres Moduls hinzu, falls vorhanden

#endif /* DECT2020_MODULE_H */
